# Some global variables for interactor

pick_radius = 5
layer_hysteresis = 4

thickness_color = 'black'
interface_color = 'black'
disabled_color  = 'gray'
active_color    = 'red'
rho_color       = 'black'
rhoI_color      = 'green'
rhoM_color      = 'blue'
thetaM_color    = 'orange'
profile_color   = 'cyan'
title_color     = 'red'

vf_scale = 0.4
